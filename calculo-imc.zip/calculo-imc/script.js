const estado = {
  resultado: null,      // último cálculo { imc, classificacao, classe, pesoMin, pesoMax }
  historico: []         // lista de cálculos anteriores
};

function calcularIMC(peso, altura) {
  return peso / (altura * altura);
}

function classificar(imc) {
  if (imc < 18.5)      return { texto: "Abaixo do peso", classe: "abaixo" };
  if (imc < 25)        return { texto: "Peso normal",    classe: "normal" };
  if (imc < 30)        return { texto: "Sobrepeso",      classe: "sobrepeso" };
  if (imc < 35)        return { texto: "Obesidade Grau I", classe: "obesidade-1" };
  if (imc < 40)        return { texto: "Obesidade Grau II", classe: "obesidade-2" };
  return                 { texto: "Obesidade Grau III", classe: "obesidade-3" };
}

function renderResultado() {
  const div = document.getElementById("resultado");

  if (estado.resultado === null) {
    div.innerHTML = "";
    return;
  }

  const { imc, classificacao, pesoMin, pesoMax } = estado.resultado;
  div.innerHTML = `
    <div class="card ${classificacao.classe}">
      <strong>Seu IMC: ${imc.toFixed(2)}</strong><br>
      Classificação: ${classificacao.texto}<br>
      <span class="peso-ideal">Peso ideal estimado: ${pesoMin} kg – ${pesoMax} kg</span>
    </div>
  `;
}

function renderHistorico() {
  const container = document.getElementById("historico-container");
  const ul = document.getElementById("historico");
  ul.innerHTML = "";

  if (estado.historico.length === 0) {
    container.style.display = "none";
    return;
  }

  container.style.display = "block";

  estado.historico.forEach((item, index) => {
    const li = document.createElement("li");
    li.innerHTML = `
      <span>IMC ${item.imc.toFixed(2)} — ${item.classificacao.texto}</span>
      <button class="btn-remover" data-index="${index}" title="Remover item">✕</button>
    `;
    ul.appendChild(li);
  });

  // Adicionar eventos aos botões de remoção
  document.querySelectorAll(".btn-remover").forEach(btn => {
    btn.addEventListener("click", function() {
      const idx = parseInt(this.getAttribute("data-index"));
      removerItem(idx);
    });
  });
}

function removerItem(index) {
  estado.historico.splice(index, 1);
  render();
}

function limparHistorico() {
  estado.historico = [];
  estado.resultado = null;
  render();
}

function render() {
  renderResultado();
  renderHistorico();
}

document.getElementById("btn-limpar").addEventListener("click", limparHistorico);

document.getElementById("form-imc").addEventListener("submit", function (e) {
  e.preventDefault();

  const pesoInput = document.getElementById("peso").value;
  const alturaInput = document.getElementById("altura").value;
  const errorDiv = document.getElementById("error-msg");

  // Validação: campos vazios, peso <= 0, altura <= 0 ou altura > 2.5
  const peso = parseFloat(pesoInput);
  const altura = parseFloat(alturaInput);

  if (!pesoInput || !alturaInput || isNaN(peso) || isNaN(altura) || peso <= 0 || altura <= 0 || altura > 2.5) {
    errorDiv.textContent = "Erro: Preencha valores válidos. O peso deve ser positivo e a altura deve ser entre 0 e 2,5 metros.";
    errorDiv.style.display = "block";
    return;
  }

  // Ocultar erro se tudo estiver correto
  errorDiv.style.display = "none";

  const imc = calcularIMC(peso, altura);
  const classificacao = classificar(imc);

  // Desafio: Peso ideal (IMC 18.5 a 24.9)
  const pesoMin = (18.5 * (altura * altura)).toFixed(1);
  const pesoMax = (24.9 * (altura * altura)).toFixed(1);

  estado.resultado = { imc, classificacao, pesoMin, pesoMax };
  estado.historico = [{ imc, classificacao }, ...estado.historico];

  render();
});
